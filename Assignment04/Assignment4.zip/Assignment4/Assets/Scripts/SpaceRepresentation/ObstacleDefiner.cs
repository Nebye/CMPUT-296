﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObstacleDefiner : MonoBehaviour
{
	public float width;
	public float height;
	public virtual Vector2[][] GetObstaclePoints()
	{
		return null;
	}
    
}
