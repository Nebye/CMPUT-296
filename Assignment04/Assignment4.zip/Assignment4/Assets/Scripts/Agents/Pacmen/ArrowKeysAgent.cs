﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ArrowKeysAgent : MonoBehaviour
{
    private Vector3 target;
    private bool movingTowardTarget = false;
    public bool MovingTowardTarget { get { return movingTowardTarget; } }

    private const int RIGHT = 0, DOWN = 1, LEFT = 2, UP = 3;
    private int currDirection = 0;//0 = right, 1 = down, 2 = left, 3 = up


    private float speed = AgentConstants.SPEED;
    public void SetTarget(Vector3 _target)
    {
        target = _target;
        if (Mathf.Abs(transform.position.x - target.x) < AgentConstants.EPSILON)//Special case moving vertically
        {
            Vector3 eulerAngles = transform.eulerAngles;
            if (transform.position.y < target.y)
            {
                eulerAngles.x = -90;
            }
            else
            {
                eulerAngles.x = 90;
            }
            transform.eulerAngles = eulerAngles;
        }
        else
        {
            transform.LookAt(target, Vector3.up);
        }
        movingTowardTarget = true;
    }

    void Start()
    {
        Vector3 currPos = transform.position;
        currPos += new Vector3(0.001f, 0, 0);
        SetTarget(currPos);
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKey(KeyCode.RightArrow))
        {
            currDirection = RIGHT;
            movingTowardTarget = true;
        }
        else if (Input.GetKey(KeyCode.DownArrow))
        {
            currDirection = DOWN;
            movingTowardTarget = true;
        }
        else if (Input.GetKey(KeyCode.LeftArrow))
        {
            currDirection = LEFT;
            movingTowardTarget = true;
        }
        else if (Input.GetKey(KeyCode.UpArrow))
        {
            currDirection = UP;
            movingTowardTarget = true;
        }

        if (movingTowardTarget)
        {
            if (currDirection == RIGHT)
            {
                SetTarget(HW3NavigationHandler.Instance.NodeHandler.ClosestNode(transform.position + Vector3.right * 0.2f).Location);
            }
            else if (currDirection == DOWN)
            {
                SetTarget(HW3NavigationHandler.Instance.NodeHandler.ClosestNode(transform.position + Vector3.down * 0.2f).Location);
            }
            else if (currDirection == LEFT)
            {
                SetTarget(HW3NavigationHandler.Instance.NodeHandler.ClosestNode(transform.position + Vector3.left * 0.2f).Location);
            }
            else if (currDirection == UP)
            {
                SetTarget(HW3NavigationHandler.Instance.NodeHandler.ClosestNode(transform.position + Vector3.up * 0.2f).Location);
            }
        }

        if (movingTowardTarget)
        {
            if ((target - transform.position).sqrMagnitude < AgentConstants.THRESHOLD)
            {
                movingTowardTarget = false;
                transform.position = target;
            }
            else
            {
                Vector3 potentialNewPosition = transform.position + (target - transform.position).normalized * Time.deltaTime * speed;
                if (ObstacleHandler.Instance.AnyIntersect(new Vector2(transform.position.x, transform.position.y), new Vector2(potentialNewPosition.x, potentialNewPosition.y)))
                {
                    movingTowardTarget = false;
                }
                else
                {
                    transform.position = potentialNewPosition;
                }
            }

        }
    }
}
